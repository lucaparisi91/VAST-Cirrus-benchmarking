#!/bin/bash

echo $*
